#include "stdafx.h"

extern void GenerateFeature(char *filename, char *featureFile);
extern int DisplayFeature(char *filename, char*);
extern int SIFTMatch(char *filename1, char *filename2);


void main()
{
	char filename[1024] = "beaver.png";
	char filename2[1024] = "beaver_xform.png";
	char featureFile[1024] = "feature.dat";
	//SIFTOnline();
	//GenerateFeature(filename,featureFile);
	// DisplayFeature(filename, featureFile);
	SIFTMatch(filename, filename2);
}